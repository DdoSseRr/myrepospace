import telebot

import sqlite3
from telebot import types
import lists



bot=telebot.TeleBot("2066370851:AAGqPiGB7YV2GrM10c5-sx02blGGzdtA1js", parse_mode='html')
owner='1802062999'












@bot.message_handler(commands='help')
def help(message):
    if message.text == '/help':
        bot.send_photo(message.chat.id, photo=open('/Users/macbookpro/PycharmProjects/pythonProject repair/pics/inst1.jpg', 'rb'), caption='Шаг 1',reply_markup=None)
        bot.send_photo(message.chat.id, photo=open('/Users/macbookpro/PycharmProjects/pythonProject repair/pics/inst2.jpg', 'rb'), caption='Шаг 2',reply_markup=None)
        bot.send_photo(message.chat.id, photo=open('/Users/macbookpro/PycharmProjects/pythonProject repair/pics/inst3.jpg', 'rb'), caption='Шаг 3',reply_markup=None)
        bot.send_photo(message.chat.id,photo=open('/Users/macbookpro/PycharmProjects/pythonProject repair/pics/inst4.jpg', 'rb'),caption='Шаг 4', reply_markup=None)
        bot.send_photo(message.chat.id,photo=open('/Users/macbookpro/PycharmProjects/pythonProject repair/pics/inst5.jpg', 'rb'),caption='Шаг 5', reply_markup=None)
        bot.send_photo(message.chat.id,photo=open('/Users/macbookpro/PycharmProjects/pythonProject repair/pics/inst6.jpg', 'rb'),caption='Шаг 6', reply_markup=None)
        bot.send_photo(message.chat.id,photo=open('/Users/macbookpro/PycharmProjects/pythonProject repair/pics/inst7.jpg', 'rb'),caption='Шаг 7', reply_markup=None)
        km1 = types.KeyboardButton('Купить 🛒📦')
        km2 = types.KeyboardButton('Каюта Капитана 📞📲')
        km3 = types.KeyboardButton('О нас ☠️')
        main = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True).row(km1, km2).row(km3)
        bot.send_photo(message.chat.id, photo=open('/Users/macbookpro/PycharmProjects/pythonProject repair/pics/inst8.jpg', 'rb'), caption='Шаг 8',reply_markup=main)

@bot.message_handler(commands=['start','url'])


def welcome(message):
    connect = sqlite3.connect('adsflash.db')
    cursor = connect.cursor()

    connect.commit()

    user_id = [message.chat.id]
    cursor.execute("INSERT OR IGNORE INTO 'users_id' ('id') VALUES(?);", user_id)
    connect.commit()

    km1=types.KeyboardButton('Купить 🛒📦')
    km2 =types.KeyboardButton('Каюта Капитана 📞📲')
    km3=types.KeyboardButton('О нас ☠️')
    main=types.ReplyKeyboardMarkup(resize_keyboard= True,one_time_keyboard=True).row(km1,km2).row(km3)
    with open('/Users/macbookpro/PycharmProjects/pythonProject1.2/pics/pirates.jpg','rb') as video1:
     bot.send_photo(message.chat.id, video1  ,caption="<b>Приветствуем тебя на корабле ⛵️🏴‍Черная Жемчужина⛵️🏴</b>\n"
            "<b>🤖Бот автопродаж и капитан Джек☠ Помогут тебе</b>\n<b>С выбором товара, поддержат в вопросах оплаты и находа</b>\n<b><i>У нас ты можешь найти:</i></b>\n"
             "➖➖➖➖➖➖➖➖➖➖➖➖\n"
             "Шишки \n"
             "AMPHETAMINE HQ\n"
             "MDMA EXTAZY (ешки)\n"
             "MDMA в кристаллах\n"
             "A-PVP(Скорость)\n"
             "Метамфетамин\n"
             "Мефедрон Мука/Крис Импорт\n"
             "Кокаин Peru\n"
             "Метадон\n"
             "Героин Хмурый AFGAN\n\n"                                                      
             "Нажымай КУПИТЬ и отплываем", reply_markup=main)
@bot.message_handler(content_types='text')
def cityes(message):
    if message.text=='Купить 🛒📦':
        ct=bot.send_message(message.chat.id, '➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                             '<b>НАПИШИТЕ СВОЙ ГОРОД:</b>\n'
                                             '➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                             '<b>❗️ПОЛНЫМ НАЗВАНИЕМ❗️</b>\n'
                                             '<b>❗️БЕЗ СОКРАЩЕНИЙ❗️</b>\n'
                                             '<b>❗️ТОЛЬКО НА РУССКОМ ЯЗЫКЕ❗️</b>\n'
                                             '<b>❗️И С ЗАГЛАВНОЙ БУКВЫ❗️</b>\n'
                                             '➖➖➖➖➖➖➖➖➖➖➖➖➖➖',reply_markup=None)
        bot.register_next_step_handler(ct,ua)
    elif message.text=='О нас ☠️':
        bot.send_photo(message.chat.id,photo=open('/Users/macbookpro/PycharmProjects/pythonProject1.2/pics/default.png','rb') ,
                       caption='➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                                           
                                                   '<b><i>Работаем 24/7 для того чтобы ВЫ:</i></b>\n'
                                                   'Всегда получали только свежие клады '
                                                   'вовремя и без каких либо проблем\n'
                                                   'Наши кладмэны проходят тройные проверки и недели обучения'
                                                   'прежде чем приступить к работе\n'
                                                   'Мы гарантируем соотношение цена=качество во всех аспектах\n'
                                                   'Нашей нелегкой работы\n'
                                                   '➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                                   '<b>🎁Типы кладов:</b> <b>только МАГНИТ</b>\n'
                                                   'Что такое магнит?Для тех кто до сих пор '
                                                   'рылся в земле в поисках клобка изоленты.\n'
                                                   '✅Магнит - это тип клада который крепиться к чему то\n'
                                                   'И находиться при этом в укромном месте!\n'
                                                   'Например:\nCиняя изолента прикреплена к задней части батарии в подьезде между 5 и 6 этажами!\n'
                                                   '➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                                   '<b>Отзывы о нашей работе можно посмотреть тут</b>\n'
                                                   '👇👇👇👇👇👇👇👇👇👇👇👇\n\n'
                                                   '➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                                   '<b>Чтобы вернуться в главное меню введите команду /start </b>', reply_markup=None)


    elif message.text=='Каюта Капитана 📞📲':
        ssylka = types.InlineKeyboardMarkup()
        btn = types.InlineKeyboardButton(text='Кнопка связи с оператором', url='https://blackpearl.casa')
        ssylka.add(btn)
        bot.send_message(message.chat.id,
                         'Нажмите на кнопку выше для перехода на оператора.\nЧтобы продолжить пользоваться ботом введите команду /start',
                         reply_markup=ssylka)


def ua(message):

    for oneof in lists.ua_cities:
        if message.text==oneof:
           towua1=types.KeyboardButton('СК A-PVP Кристалл 💎')
           towua2=types.KeyboardButton('Кокаин FishScale VHQ (Peru) 🥥')
           towua3=types.KeyboardButton('Амфетамин Premium ✴️')
           towua4=types.KeyboardButton('Метадон VHQ 🍯')
           towua5=types.KeyboardButton('Мефедрон Крис 💎')
           towua6=types.KeyboardButton('Экстази XTC 💊')
           towua7=types.KeyboardButton('MDMA 95%Champange 🥂')
           towua8=types.KeyboardButton('Героин Хмурый AFGAN 🌶️')
           towua9=types.KeyboardButton('Марихуана(Шишки) ☘️')
           towua10=types.KeyboardButton('Гашиш ICEOLATOR 🍫')
           back=types.KeyboardButton('Назад❎')
           towar=types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua9,towua1).row(towua10,towua3).row(towua4,towua5).row(towua6,towua7).row(towua8,towua2).row(back)
           twr=bot.send_message(message.chat.id,'Выберите товар',reply_markup=towar)
           bot.register_next_step_handler(twr,priceua)
           return priceua



    for oneof1 in lists.ru_cities:
        if message.text == oneof1:
            towua1 = types.KeyboardButton('СК A-PVP Кристалл 💎')
            towua2 = types.KeyboardButton('Кокаин FishScale VHQ (Peru) 🥥')
            towua3 = types.KeyboardButton('Амфетамин Premium ✴️')
            towua4 = types.KeyboardButton('Метадон VHQ 🍯')
            towua5 = types.KeyboardButton('Мефедрон Крис 💎')
            towua6 = types.KeyboardButton('Экстази XTC 💊')
            towua7 = types.KeyboardButton('MDMA 95%Champange 🥂')
            towua8 = types.KeyboardButton('Героин Хмурый AFGAN 🌶️')
            towua9 = types.KeyboardButton('Марихуана(Шишки) ☘️')
            towua10 = types.KeyboardButton('Гашиш ICEOLATOR 🍫')
            back=types.KeyboardButton('Назад❎')
            towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua9, towua1).row(towua10, towua3).row(towua4,towua5).row(towua6, towua7).row(towua8,towua2).row(back)
            nxt = bot.send_message(message.chat.id, 'Выберите товар', reply_markup=towar)
            bot.register_next_step_handler(nxt, priceru)
            return priceru





    else:
        km1 = types.KeyboardButton('Купить 🛒📦')
        km2 = types.KeyboardButton('Каюта Капитана 📞📲')
        km3 = types.KeyboardButton('О нас ☠️')
        main = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True).row(km1, km2).row(km3)
        bot.send_message(message.chat.id, 'Город не найден либо указан не верно нажмите "Купить" и попробуйте еще раз ',reply_markup=main)



def priceua(message):
        if message.text=='Назад❎':
          back=bot.send_message(message.chat.id,'Вы вепнулись в главное Меню')
          bot.register_next_step_handler(back,welcome)
          return welcome(message)




        if message.text=='Гашиш ICEOLATOR 🍫' :
             towua1 = types.KeyboardButton('1г - 350UAH')
             towua2 = types.KeyboardButton('2г - 600UAH')
             towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua1).row(towua2)
             ves=bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
             bot.register_next_step_handler(ves,loc)
             return loc(message)




        if message.text=='СК A-PVP Кристалл 💎' :
             towua1 = types.KeyboardButton('0,25 - 230UAH')
             towua2 = types.KeyboardButton('0,5 - 380UAH')
             towua3 = types.KeyboardButton('1 - 580UAH')
             towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua1).row(towua2).row(towua3)
             ves=bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
             bot.register_next_step_handler(ves,loc)
             return loc(message)

        if message.text=='Кокаин FishScale VHQ (Peru) 🥥':
            towua4 = types.KeyboardButton('0,25 - 1640UAH')
            towua5 = types.KeyboardButton('0,5 - 2700UAH')
            towua6 = types.KeyboardButton('1 - 4300UAH')
            towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua5).row(towua6)
            ves=bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
            bot.register_next_step_handler(ves, loc)
            return loc(message)

        if message.text=='Амфетамин Premium ✴️':
            towua4 = types.KeyboardButton('0,5 - 250UAH')
            towua5 = types.KeyboardButton(' 1 - 380UAH')
            towua6 = types.KeyboardButton(' 3 - 850UAH')
            towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua5).row(towua6)
            ves=bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
            bot.register_next_step_handler(ves, loc)
            return loc(message)

        if message.text=='Метадон VHQ 🍯':
            towua4 = types.KeyboardButton('0,25г - 500UAH')
            towua5 = types.KeyboardButton('0,5г - 900UAH')
            towua6 = types.KeyboardButton('1г - 1500UAH')
            towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua5).row(towua6)
            ves=bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
            bot.register_next_step_handler(ves, loc)
            return loc(message)

        if message.text=='Мефедрон Крис 💎':
            towua4 = types.KeyboardButton('0,25 - 240UAH')
            towua5 = types.KeyboardButton('0,5 - 390UAH')
            towua6 = types.KeyboardButton(' 1 - 650UAH')
            towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua5).row(towua6)
            ves=bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
            bot.register_next_step_handler(ves, loc)
            return loc(message)

        if message.text=='Экстази XTC 💊':
            towua4 = types.KeyboardButton('Barcelona🇪🇸(220mg)1шт - 320UAH')
            towua5 = types.KeyboardButton('Maybach 🏎(240mg)1шт - 330UAH')
            towua6 = types.KeyboardButton('Yellow Tesla📒(300mg)1шт - 350UAH')
            towua7 = types.KeyboardButton('Barcelona🇪🇸(220mg)2шт - 580UAH')
            towua8 = types.KeyboardButton('Maybach 🏎(240mg)2шт - 590UAH')
            towua9 = types.KeyboardButton('Yellow Tesla📒(300mg)2шт - 680UAH')
            towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua7).row(towua5).row(towua8).row(towua6).row(towua9)
            ves=bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
            bot.register_next_step_handler(ves, loc)
            return loc(message)

        if message.text=='MDMA 95%Champange 🥂':
            towua4 = types.KeyboardButton('0,25 - 300UAH')
            towua5 = types.KeyboardButton('0,5 - 450UAH')
            towua6 = types.KeyboardButton(' 1 - 800UAH')
            towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua5).row(towua6)
            ves=bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
            bot.register_next_step_handler(ves, loc)
            return loc(message)

        if message.text == 'Героин Хмурый AFGAN 🌶️':
            towua1 = types.KeyboardButton('0,25 - 600UAH')
            towua2 = types.KeyboardButton('0,5 - 1000UAH')
            towua3 = types.KeyboardButton('1 - 1600UAH')
            towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua1).row(towua2).row(towua3)
            ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
            bot.register_next_step_handler(ves, loc)
            return loc(message)

        if message.text=='Марихуана(Шишки) ☘️':
            towua4 = types.KeyboardButton('Царь Египта 1г - 230UAH')
            towua5 = types.KeyboardButton('Царь Египта 2г - 420UAH')
            towua10 = types.KeyboardButton('Царь Египта 3г - 630UAH')
            towua6 = types.KeyboardButton('Devil Indika 1г - 230UAH')
            towua7 = types.KeyboardButton('Devil Indika 2г - 420UAH')
            towua11 = types.KeyboardButton('Devil Indika 3г - 630UAH')
            towua8 = types.KeyboardButton('Белая Вдова 1г - 290UAH')
            towua9 = types.KeyboardButton('Белая Вдова 2г - 460UAH')
            towua12 = types.KeyboardButton('Белая Вдова 3г - 690UAH')
            towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4, towua5).row(towua10, towua6).row(towua7,towua11).row(towua8,towua9).row(towua12)
            ves=bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
            bot.register_next_step_handler(ves, loc)
            return loc(message)









def priceru(message):
    if message.text == 'Назад❎':
        back = bot.send_message(message.chat.id, 'Вы вернулись в главное Меню')
        bot.register_next_step_handler(back, welcome)
        return welcome(message)

    if message.text == 'Гашиш ICEOLATOR 🍫':
        towua1 = types.KeyboardButton('1г - 1900руб')
        towua2 = types.KeyboardButton('2г - 3400руб')
        towua3 = types.KeyboardButton('3г - 4200руб')
        towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua1).row(towua2).row(towua3)
        ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
        bot.register_next_step_handler(ves, loc)

    if message.text == 'СК A-PVP Кристалл 💎':
        towua1 = types.KeyboardButton('0,5г - 1800руб')
        towua2 = types.KeyboardButton('1г - 2800руб')
        towua3 = types.KeyboardButton('2г - 3900руб')
        towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua1).row(towua2).row(towua3)
        ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
        bot.register_next_step_handler(ves, loc)

    if message.text == 'Кокаин FishScale VHQ (Peru) 🥥':
        towua4 = types.KeyboardButton('0,5г - 6500руб')
        towua5 = types.KeyboardButton('1г - 12000руб')
        towua6 = types.KeyboardButton('2г - 19000руб')
        towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua5).row(towua6)
        ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
        bot.register_next_step_handler(ves, loc)

    if message.text == 'Амфетамин Premium ✴️':
        towua4 = types.KeyboardButton('1г - 1500руб')
        towua5 = types.KeyboardButton('2г - 2500руб')
        towua6 = types.KeyboardButton('3г - 3200руб')
        towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua5).row(towua6)
        ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
        bot.register_next_step_handler(ves, loc)

    if message.text == 'Метадон VHQ 🍯':
        towua4 = types.KeyboardButton('0,5г - 2500руб')
        towua5 = types.KeyboardButton('1г - 4500руб')
        towua6 = types.KeyboardButton('1,5г - 6300руб')
        towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua5).row(towua6)
        ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
        bot.register_next_step_handler(ves, loc)

    if message.text == 'Мефедрон Крис 💎':
        towua4 = types.KeyboardButton('0,5г - 2100руб')
        towua5 = types.KeyboardButton('1г - 3900руб')
        towua6 = types.KeyboardButton('2г - 6800руб')
        towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua5).row(towua6)
        ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
        bot.register_next_step_handler(ves, loc)

    if message.text == 'Экстази XTC 💊':
        towua4 = types.KeyboardButton('Barcelona🇪🇸(220mg)1шт - 1200руб')
        towua5 = types.KeyboardButton('Maybach 🏎(240mg)1шт - 1400руб')
        towua6 = types.KeyboardButton('Yellow Tesla📒(300mg)1шт - 1700руб')
        towua7 = types.KeyboardButton('Barcelona🇪🇸(220mg)2шт - 1900руб')
        towua8 = types.KeyboardButton('Maybach 🏎(240mg)2шт - 2300руб')
        towua9 = types.KeyboardButton('Yellow Tesla📒(300mg)2шт - 2900руб')
        towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua7).row(towua5).row(towua8).row(towua6).row(towua9)
        ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
        bot.register_next_step_handler(ves, loc)

    if message.text == 'MDMA 95%Champange 🥂':
        towua4 = types.KeyboardButton('0,5г - 1700руб')
        towua5 = types.KeyboardButton('1г - 2900руб')
        towua6 = types.KeyboardButton('2г - 5000руб')
        towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4).row(towua5).row(towua6)
        ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
        bot.register_next_step_handler(ves, loc)

    if message.text == 'Героин Хмурый AFGAN 🌶️':
        towua1 = types.KeyboardButton('0,5г - 2000руб')
        towua2 = types.KeyboardButton('1г - 3800руб')
        towua3 = types.KeyboardButton('2г - 6000руб')
        towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua1).row(towua2).row(towua3)
        ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
        bot.register_next_step_handler(ves, loc)

    if message.text == 'Марихуана(Шишки) ☘️':
        towua4 = types.KeyboardButton('Gorilla Glue 1г - 1900руб')
        towua5 = types.KeyboardButton('Gorilla Glue 2г - 3300руб')
        towua10 = types.KeyboardButton('Gorilla Glue 3г - 4100руб')
        towua6 = types.KeyboardButton('AK-47 1г - 2100руб')
        towua7 = types.KeyboardButton('АК-47 2г - 3500руб')
        towua11 = types.KeyboardButton('АК-47 5г - 6000руб')
        towua8 = types.KeyboardButton('Белая Вдова 1г - 2100руб')
        towua9 = types.KeyboardButton('Белая Вдова 2г - 3500руб')
        towua12 = types.KeyboardButton('Белая Вдова 3г - 4500руб')
        towar = types.ReplyKeyboardMarkup(resize_keyboard=True).row(towua4, towua5).row(towua10, towua6).row(towua7,towua11).row(towua8,towua9).row(towua12)
        ves = bot.send_message(message.chat.id, 'Выберите вес', reply_markup=towar)
        bot.register_next_step_handler(ves, loc)







def loc(message):
  for picyua in lists.ua_prices:
    if message.text==picyua:
      locua=types.KeyboardButton(text='Отправить локацию',request_location=True)
      delloc=types.KeyboardButton('Не оправлять локацию!',request_location=None)
      locreq=types.ReplyKeyboardMarkup(resize_keyboard=True,one_time_keyboard=True)
      locreq.add(locua,delloc)
      loc=bot.send_message(message.chat.id, 'Отправьте свою локацию для подбора ближайшего клада.\n\n'
                                            'Если не хотите отправлять локацию нажмите на соответсвующую кнопку\n'
                                            'Расположение(район) клада будет подобрано случайным образом!', reply_markup=locreq)
      bot.register_next_step_handler(loc,oplataua)





  for picyru in lists.ru_prices:
    if message.text == picyru:
       locru = types.KeyboardButton(text='Отправить локацию!', request_location=True)
       delloc = types.KeyboardButton('Не оправлять локацию!',request_location=None)
       locrf = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
       locrf.add(delloc, locru)
       loc1 = bot.send_message(message.chat.id, 'Отправьте свою локацию для подбора ближайшего клада(ФУНКЦИЯ ПОКА НЕДОСТУПНА В ВАШЕМ ГОРОДЕ НАЖМИТЕ НЕ ОТПРАВЛЯТЬ!).\n\n'
                                                'Если не хотите отправлять локацию нажмите на соответсвующую кнопку\n'
                                                'Расположение(район) клада будет подобрано случайным образом!',reply_markup=locrf)
       bot.register_next_step_handler(loc1, oplataru)













@bot.message_handler(content_types='location')
def oplataua(message):

 if message.location is not None:
   opl1ua=types.KeyboardButton('Оплатить')
   oplatavdf=types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True )
   oplatavdf.add(opl1ua)
   xyz1=bot.send_photo(message.chat.id, photo=open('/Users/macbookpro/PycharmProjects/pythonProject1.2/pics/default.png','rb'),caption=
                                     'Хорошый выбор!\n'
                                     'Оплата по номеру телефона\n'
                                     '➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                     '<b>+380500472063</b> Vodafone\n'
                                     '➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                     'Просто пополняете счёт на телефон\n'
                                     'Нажмите "Оплатить" после чего скиньте боту фотографию чека либо скрин оплаты\n', reply_markup=oplatavdf)
   bot.register_next_step_handler(xyz1,photo)

 elif message.location is None:
     opl1ua = types.KeyboardButton('Оплатить')
     oplatavdf = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
     oplatavdf.add(opl1ua)
     xyz1 = bot.send_photo(message.chat.id, photo=open('/Users/macbookpro/PycharmProjects/pythonProject1.2/pics/default.png','rb'), caption=
                                              'Хорошый выбор!\nОплата по номеру телефона\n'
                                              '➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                              '<b>+380500472063</b> Vodafone\n'
                                              '➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                              'Просто пополняете счёт на телефон\n'
                                               'Нажмите "Оплатить" после чего скиньте боту фотографию чека либо скрин оплаты\n', reply_markup=oplatavdf)
     bot.register_next_step_handler(xyz1,photo)


@bot.message_handler(content_types='location')
def oplataru(message):
  if message.location is not None:
    opl1ua = types.KeyboardButton('Оплатить')
    oplatavdf = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    oplatavdf.add(opl1ua)
    xyz2=bot.send_photo(message.chat.id, photo=open('/Users/macbookpro/PycharmProjects/pythonProject1.2/pics/default.png','rb'),caption=
                                     'Хорошый выбор!\nОплата на Qiwi\n '
                                     '➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                     '<b>4890494729095695   Карта киви банка</b>\n<b>Выберите перевод на карту другого банка</b>\n'
                                     '<b>+7-977-917-23-22 Номер киви кошелька</b>\n'
                                     '➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                     'Нажмите "Оплатить" после чего скиньте боту фотографию чека либо скрин оплаты\n', reply_markup=oplatavdf)
    bot.register_next_step_handler(xyz2,photo)


  elif message.location is None:
      opl1ua = types.KeyboardButton('Оплатить')
      oplatavdf = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
      oplatavdf.add(opl1ua)
      xyz2 = bot.send_photo(message.chat.id, photo=open('/Users/macbookpro/PycharmProjects/pythonProject1.2/pics/default.png','rb'),caption=
                                               'Хорошый выбор!\nОплата на Qiwi кошелек\n'
                                               '➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                               '<b>+79779257060 Номер кошелька</b>\n<b>4890494729095695   Карта киви банка</b>\n'
                                               '➖➖➖➖➖➖➖➖➖➖➖➖\n'
                                               'Нажмите "Оплатить" после чего скиньте боту фотографию чека либо скрин оплаты\n', reply_markup=oplatavdf)
      bot.register_next_step_handler(xyz2,photo)









@bot.message_handler(content_types=['photo'])
def photo(message):
  try:
    fileID = message.photo[-1].file_id
    print('fileID=',fileID)
    bot.send_photo(owner,fileID)
    a1=types.KeyboardButton('Повторить попытку')
    tot=types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
    tot.add(a1)
    wyz=bot.send_message(message.chat.id, '<b>Пожалуйста подождите проверяем оплату...</b>⌛\n\n\n(ЕСЛИ В ТЕЧЕНИИ 5-И МИНУТ БОТ НЕ ОТВЕТИТ НАЖМИТЕ НА КНОПКУ "ПОВТОРИТЬ ПОПЫТКУ" ФОТО ЕЩЕ РАЗ ОТПРАВЛЯТЬ НЕ НАДО)', reply_markup=tot)
    bot.register_next_step_handler(wyz,nopay)


  except:
    pass


def nopay(message):
   if message.text == 'Повторить попытку':
    bot.send_message(message.chat.id, 'Обработка:')
    oper=types.KeyboardButton(text='Каюта Капитана 📞📲')
    nazad=types.KeyboardButton('В главное меню')
    sviaz=types.ReplyKeyboardMarkup(resize_keyboard=True)
    sviaz.add(oper,nazad)
    xyz=bot.send_photo(message.chat.id, photo=open('/Users/macbookpro/PycharmProjects/pythonProject1.2/pics/trnf.png','rb'), caption='Транзакция не найдена.\nПожалуйста повторите попытку позже или войдите в Каюту Капитана и обратитесь к Джэку',reply_markup=sviaz)
    bot.register_next_step_handler(xyz,oprtr)




def oprtr(message):
 if message.text=='Каюта Капитана 📞📲':

    ssylka=types.InlineKeyboardMarkup()
    btn=types.InlineKeyboardButton(text='Кнопка связи с каитаном Джэком',url='https://blackpearl.casa')
    ssylka.add(btn)
    bot.send_message(message.chat.id,'Нажмите на кнопку выше для перехода на оператора.\nЧтобы продолжить пользоваться ботом введите команду /start',reply_markup=ssylka)

 if message.text == 'В главное меню':
     xyz3 = bot.send_message(message.chat.id, 'Вы вернулись в Главное Меню',)
     bot.register_next_step_handler(xyz3, welcome)
     return welcome(message)












bot.polling(none_stop=True)
